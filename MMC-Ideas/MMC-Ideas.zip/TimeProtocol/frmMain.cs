﻿//********************************************************************
// frmMain - The Main Form
// (c) Okt 2010 MMC
//********************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using Microsoft.Win32;

//********************************************************************
namespace TimeProtocol
{
    public partial class frmMain : Form
    {
        //************************************************************
        static string GetTimeStamp(DateTime dt)
        {
            //DateTime dt = DateTime.Now;
            string ts = dt.ToString();
            ts += ':';
            ts += dt.Millisecond.ToString("D3");
            return ts;
        }

        //************************************************************
        protected string _FileName;
        protected StreamWriter _FileStream;
        protected DateTime _Log_Last;
        protected DateTime _Log_First;

        public frmMain()
        {
            InitializeComponent();
            _FileName = null;
            _FileStream = null;
            _Log_First = DateTime.MinValue;
            _Log_Last = DateTime.MinValue;

            ssdSeconds.Value = 0;
            ssdMinutes.Value = 0;
            ssdHours.Value = 0;
        }

        //------------------------------------------------------------
        private void frmMain_Load(object sender, EventArgs e)
        {
            SystemEvents.PowerModeChanged += new PowerModeChangedEventHandler(SystemEvents_PowerModeChanged);
            SystemEvents.SessionSwitch += new SessionSwitchEventHandler(SystemEvents_SessionSwitch);
        }

        //************************************************************
        protected void File_Open(string FileName)
        {
            _FileName = FileName;
            _FileStream = File.CreateText(_FileName);
        }

        //------------------------------------------------------------
        protected void File_Close()
        {
            if (_FileStream != null) _FileStream.Close();
            _FileStream = null;
            _FileName = null;
        }
        
        //************************************************************
        public void WriteText(string Text)
        {
            txtProtocol.AppendText(Text);
            if (_FileStream != null)
            {
                _FileStream.Write(Text);
                _FileStream.Flush();
            }
        }

        //------------------------------------------------------------
        public void Log(string Message)
        {
            DateTime log = DateTime.Now;
            if (_Log_Last.Date < log.Date)
            {
                WriteText("*********************************************\n");
                TimeSpan span = _Log_Last - _Log_First;
                if (span.Seconds > 0)
                {
                    WriteText("TimeSpan: " + span.ToString() + '\n');
                    WriteText("*********************************************\n");
                }
                _Log_First = log;
            }
            WriteText(GetTimeStamp(log) + '\t' + Message + '\n');
            _Log_Last = log;
        }

        //************************************************************
        public void SystemEvents_PowerModeChanged(Object sender, PowerModeChangedEventArgs e)
        {
            switch (e.Mode)
            {
                case PowerModes.Resume:
                    Log("Resume");
                    break;
                case PowerModes.StatusChange:
                    // Log("PowerChange");  // ignore this one due to flooding
                    break;
                case PowerModes.Suspend:
                    Log("Suspend");
                    break;
                default:
                    Log("Unknown PowerModeChange event");
                    break;
            }
        }

        //------------------------------------------------------------
        public void SystemEvents_SessionSwitch(Object sender, SessionSwitchEventArgs e)
        {
            switch (e.Reason)
            {
                case SessionSwitchReason.ConsoleConnect:
                    Log("ConsoleConnect");
                    break;
                case SessionSwitchReason.ConsoleDisconnect:
                    Log("Console Disconnect");
                    break;
                case SessionSwitchReason.RemoteConnect:
                    Log("RemoteConnect");
                    break;
                case SessionSwitchReason.RemoteDisconnect:
                    Log("RemoteDisconnect");
                    break;
                case SessionSwitchReason.SessionLock:
                    Log("SessionLock");
                    break;
                case SessionSwitchReason.SessionLogoff:
                    Log("SessionLogoff");
                    break;
                case SessionSwitchReason.SessionLogon:
                    Log("SessionLogon");
                    break;
                case SessionSwitchReason.SessionRemoteControl:
                    Log("SessionRemoteControl");
                    break;
                case SessionSwitchReason.SessionUnlock:
                    Log("SessionUnlock");
                    break;
                default:
                    Log("Unknown Session Switch event");
                    break;
            }
        }

        //------------------------------------------------------------
        private void btnRun_Click(object sender, EventArgs e)
        {
            if (btnRun.Text == "Start")
            {
                if (dlgFileSave.ShowDialog() == DialogResult.OK)
                {
                    File_Open(dlgFileSave.FileName);
                    btnRun.Text = "Stop";
                    Log("Started");
                    tmrClock.Enabled = true;
                }
            }
            else
            {
                btnRun.Text = "Start";
                Log("Stopped");
                File_Close();
                tmrClock.Enabled = false;
            }
        }

        //------------------------------------------------------------
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            File_Close();
        }

        //------------------------------------------------------------
        private void tmrClock_Tick(object sender, EventArgs e)
        {
            DateTime log = DateTime.Now;
            TimeSpan Span = log - _Log_First;
            ssdHours.Value = Span.Hours;
            ssdMinutes.Value = Span.Minutes;
            ssdSeconds.Value = Span.Seconds;
        }
    }
}

//********************************************************************
// END OF FILE frmMain
//********************************************************************
