﻿namespace TimeProtocol
{
    partial class frmMain
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.txtProtocol = new System.Windows.Forms.RichTextBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.dlgFileSave = new System.Windows.Forms.SaveFileDialog();
            this.tmrClock = new System.Windows.Forms.Timer(this.components);
            this.ssdHours = new MMC_Controls.Seven_Segment_Display();
            this.ssdMinutes = new MMC_Controls.Seven_Segment_Display();
            this.ssdSeconds = new MMC_Controls.Seven_Segment_Display();
            label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtProtocol
            // 
            this.txtProtocol.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProtocol.Location = new System.Drawing.Point(12, 12);
            this.txtProtocol.Name = "txtProtocol";
            this.txtProtocol.Size = new System.Drawing.Size(493, 325);
            this.txtProtocol.TabIndex = 0;
            this.txtProtocol.Text = "";
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(12, 343);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 1;
            this.btnRun.Text = "Start";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // dlgFileSave
            // 
            this.dlgFileSave.DefaultExt = "log";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label1.Location = new System.Drawing.Point(280, 399);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(16, 24);
            label1.TabIndex = 5;
            label1.Text = ":";
            // 
            // tmrClock
            // 
            this.tmrClock.Tick += new System.EventHandler(this.tmrClock_Tick);
            // 
            // ssdHours
            // 
            this.ssdHours.Digits = 2;
            this.ssdHours.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ssdHours.Location = new System.Drawing.Point(194, 373);
            this.ssdHours.Name = "ssdHours";
            this.ssdHours.Size = new System.Drawing.Size(80, 80);
            this.ssdHours.TabIndex = 4;
            // 
            // ssdMinutes
            // 
            this.ssdMinutes.Digits = 2;
            this.ssdMinutes.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ssdMinutes.Location = new System.Drawing.Point(302, 373);
            this.ssdMinutes.Name = "ssdMinutes";
            this.ssdMinutes.Size = new System.Drawing.Size(80, 80);
            this.ssdMinutes.TabIndex = 3;
            // 
            // ssdSeconds
            // 
            this.ssdSeconds.Digits = 2;
            this.ssdSeconds.ForeColor = System.Drawing.SystemColors.GrayText;
            this.ssdSeconds.Location = new System.Drawing.Point(387, 373);
            this.ssdSeconds.Name = "ssdSeconds";
            this.ssdSeconds.Size = new System.Drawing.Size(60, 50);
            this.ssdSeconds.TabIndex = 2;
            this.ssdSeconds.Thickness = 4;
            this.ssdSeconds.Value = 34;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 481);
            this.Controls.Add(label1);
            this.Controls.Add(this.ssdHours);
            this.Controls.Add(this.ssdMinutes);
            this.Controls.Add(this.ssdSeconds);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.txtProtocol);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "Time Protocol";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtProtocol;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.SaveFileDialog dlgFileSave;
        private MMC_Controls.Seven_Segment_Display ssdSeconds;
        private MMC_Controls.Seven_Segment_Display ssdMinutes;
        private MMC_Controls.Seven_Segment_Display ssdHours;
        private System.Windows.Forms.Timer tmrClock;
    }
}

