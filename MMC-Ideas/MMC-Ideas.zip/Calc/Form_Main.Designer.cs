﻿namespace Calc
{
    partial class Form_Main
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Panel pnlCalc;
            System.Windows.Forms.Button btnCalc;
            System.Windows.Forms.Panel pnlView;
            System.Windows.Forms.ToolStripMenuItem mnuCopy;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
            System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
            System.Windows.Forms.ToolStripMenuItem mnuClear;
            System.Windows.Forms.Label label1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Main));
            this.tbTerm = new System.Windows.Forms.TextBox();
            this.lbHistory = new System.Windows.Forms.ListBox();
            this.tbView = new System.Windows.Forms.RichTextBox();
            this.mnuResult = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.testToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.mnuBase = new System.Windows.Forms.ToolStripMenuItem();
            pnlCalc = new System.Windows.Forms.Panel();
            btnCalc = new System.Windows.Forms.Button();
            pnlView = new System.Windows.Forms.Panel();
            mnuCopy = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            mnuClear = new System.Windows.Forms.ToolStripMenuItem();
            label1 = new System.Windows.Forms.Label();
            pnlCalc.SuspendLayout();
            pnlView.SuspendLayout();
            this.mnuResult.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCalc
            // 
            pnlCalc.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            pnlCalc.Controls.Add(this.tbTerm);
            pnlCalc.Controls.Add(btnCalc);
            pnlCalc.Dock = System.Windows.Forms.DockStyle.Bottom;
            pnlCalc.Location = new System.Drawing.Point(0, 395);
            pnlCalc.Name = "pnlCalc";
            pnlCalc.Padding = new System.Windows.Forms.Padding(3);
            pnlCalc.Size = new System.Drawing.Size(413, 32);
            pnlCalc.TabIndex = 0;
            // 
            // tbTerm
            // 
            this.tbTerm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbTerm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTerm.Location = new System.Drawing.Point(3, 3);
            this.tbTerm.Name = "tbTerm";
            this.tbTerm.Size = new System.Drawing.Size(338, 26);
            this.tbTerm.TabIndex = 0;
            this.tbTerm.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbTerm_KeyDown);
            // 
            // btnCalc
            // 
            btnCalc.Dock = System.Windows.Forms.DockStyle.Right;
            btnCalc.Location = new System.Drawing.Point(341, 3);
            btnCalc.Name = "btnCalc";
            btnCalc.Size = new System.Drawing.Size(69, 26);
            btnCalc.TabIndex = 1;
            btnCalc.Text = "Calc";
            btnCalc.UseVisualStyleBackColor = true;
            btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // pnlView
            // 
            pnlView.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            pnlView.Controls.Add(this.lbHistory);
            pnlView.Controls.Add(this.tbView);
            pnlView.Controls.Add(label1);
            pnlView.Dock = System.Windows.Forms.DockStyle.Fill;
            pnlView.Location = new System.Drawing.Point(0, 0);
            pnlView.Name = "pnlView";
            pnlView.Padding = new System.Windows.Forms.Padding(3);
            pnlView.Size = new System.Drawing.Size(413, 395);
            pnlView.TabIndex = 2;
            // 
            // lbHistory
            // 
            this.lbHistory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHistory.FormattingEnabled = true;
            this.lbHistory.ItemHeight = 20;
            this.lbHistory.Location = new System.Drawing.Point(3, 254);
            this.lbHistory.Name = "lbHistory";
            this.lbHistory.Size = new System.Drawing.Size(338, 144);
            this.lbHistory.TabIndex = 2;
            this.lbHistory.Visible = false;
            this.lbHistory.SelectedValueChanged += new System.EventHandler(this.lbHistory_SelectedValueChanged);
            this.lbHistory.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lbHistory_KeyDown);
            // 
            // tbView
            // 
            this.tbView.BackColor = System.Drawing.SystemColors.Window;
            this.tbView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbView.ContextMenuStrip = this.mnuResult;
            this.tbView.DetectUrls = false;
            this.tbView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbView.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbView.HideSelection = false;
            this.tbView.Location = new System.Drawing.Point(3, 19);
            this.tbView.Name = "tbView";
            this.tbView.ReadOnly = true;
            this.tbView.Size = new System.Drawing.Size(407, 373);
            this.tbView.TabIndex = 0;
            this.tbView.Text = "";
            this.tbView.WordWrap = false;
            // 
            // mnuResult
            // 
            this.mnuResult.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            mnuCopy,
            this.testToolStripMenuItem,
            this.mnuBase,
            mnuClear});
            this.mnuResult.Name = "mnuResult";
            this.mnuResult.Size = new System.Drawing.Size(137, 76);
            // 
            // mnuCopy
            // 
            mnuCopy.Name = "mnuCopy";
            mnuCopy.Size = new System.Drawing.Size(136, 22);
            mnuCopy.Text = "Copy";
            mnuCopy.Click += new System.EventHandler(this.mnuCopy_Click);
            // 
            // testToolStripMenuItem
            // 
            this.testToolStripMenuItem.Name = "testToolStripMenuItem";
            this.testToolStripMenuItem.Size = new System.Drawing.Size(133, 6);
            // 
            // mnuBase
            // 
            this.mnuBase.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            toolStripMenuItem2,
            toolStripMenuItem5,
            toolStripMenuItem6,
            toolStripMenuItem7,
            toolStripMenuItem8,
            toolStripMenuItem3,
            toolStripMenuItem9,
            toolStripMenuItem4,
            toolStripMenuItem11,
            toolStripMenuItem10,
            toolStripMenuItem12,
            toolStripMenuItem13,
            toolStripMenuItem14,
            toolStripMenuItem15,
            toolStripMenuItem16});
            this.mnuBase.Name = "mnuBase";
            this.mnuBase.Size = new System.Drawing.Size(136, 22);
            this.mnuBase.Text = "Output Base";
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.CheckOnClick = true;
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem2.Tag = "";
            toolStripMenuItem2.Text = "2";
            // 
            // toolStripMenuItem5
            // 
            toolStripMenuItem5.CheckOnClick = true;
            toolStripMenuItem5.Name = "toolStripMenuItem5";
            toolStripMenuItem5.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem5.Tag = "";
            toolStripMenuItem5.Text = "8";
            // 
            // toolStripMenuItem6
            // 
            toolStripMenuItem6.Checked = true;
            toolStripMenuItem6.CheckOnClick = true;
            toolStripMenuItem6.CheckState = System.Windows.Forms.CheckState.Checked;
            toolStripMenuItem6.Name = "toolStripMenuItem6";
            toolStripMenuItem6.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem6.Tag = "";
            toolStripMenuItem6.Text = "10";
            // 
            // toolStripMenuItem7
            // 
            toolStripMenuItem7.CheckOnClick = true;
            toolStripMenuItem7.Name = "toolStripMenuItem7";
            toolStripMenuItem7.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem7.Tag = "";
            toolStripMenuItem7.Text = "16";
            // 
            // toolStripMenuItem8
            // 
            toolStripMenuItem8.CheckOnClick = true;
            toolStripMenuItem8.Name = "toolStripMenuItem8";
            toolStripMenuItem8.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem8.Text = "3";
            // 
            // toolStripMenuItem3
            // 
            toolStripMenuItem3.CheckOnClick = true;
            toolStripMenuItem3.Name = "toolStripMenuItem3";
            toolStripMenuItem3.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem3.Tag = "";
            toolStripMenuItem3.Text = "4";
            // 
            // toolStripMenuItem9
            // 
            toolStripMenuItem9.CheckOnClick = true;
            toolStripMenuItem9.Name = "toolStripMenuItem9";
            toolStripMenuItem9.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem9.Text = "5";
            // 
            // toolStripMenuItem4
            // 
            toolStripMenuItem4.CheckOnClick = true;
            toolStripMenuItem4.Name = "toolStripMenuItem4";
            toolStripMenuItem4.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem4.Tag = "";
            toolStripMenuItem4.Text = "6";
            // 
            // toolStripMenuItem11
            // 
            toolStripMenuItem11.CheckOnClick = true;
            toolStripMenuItem11.Name = "toolStripMenuItem11";
            toolStripMenuItem11.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem11.Text = "7";
            // 
            // toolStripMenuItem10
            // 
            toolStripMenuItem10.CheckOnClick = true;
            toolStripMenuItem10.Name = "toolStripMenuItem10";
            toolStripMenuItem10.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem10.Text = "9";
            // 
            // toolStripMenuItem12
            // 
            toolStripMenuItem12.CheckOnClick = true;
            toolStripMenuItem12.Name = "toolStripMenuItem12";
            toolStripMenuItem12.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem12.Text = "11";
            // 
            // toolStripMenuItem13
            // 
            toolStripMenuItem13.CheckOnClick = true;
            toolStripMenuItem13.Name = "toolStripMenuItem13";
            toolStripMenuItem13.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem13.Text = "12";
            // 
            // toolStripMenuItem14
            // 
            toolStripMenuItem14.CheckOnClick = true;
            toolStripMenuItem14.Name = "toolStripMenuItem14";
            toolStripMenuItem14.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem14.Text = "13";
            // 
            // toolStripMenuItem15
            // 
            toolStripMenuItem15.CheckOnClick = true;
            toolStripMenuItem15.Name = "toolStripMenuItem15";
            toolStripMenuItem15.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem15.Text = "14";
            // 
            // toolStripMenuItem16
            // 
            toolStripMenuItem16.CheckOnClick = true;
            toolStripMenuItem16.Name = "toolStripMenuItem16";
            toolStripMenuItem16.Size = new System.Drawing.Size(86, 22);
            toolStripMenuItem16.Text = "15";
            // 
            // mnuClear
            // 
            mnuClear.Name = "mnuClear";
            mnuClear.Size = new System.Drawing.Size(136, 22);
            mnuClear.Text = "Clear History";
            mnuClear.Click += new System.EventHandler(this.mnuClear_Click);
            // 
            // label1
            // 
            label1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            label1.Dock = System.Windows.Forms.DockStyle.Top;
            label1.Location = new System.Drawing.Point(3, 3);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(407, 16);
            label1.TabIndex = 1;
            label1.Text = "Result";
            // 
            // Form_Main
            // 
            this.AcceptButton = btnCalc;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(413, 427);
            this.Controls.Add(pnlView);
            this.Controls.Add(pnlCalc);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_Main";
            this.Text = "MMC Calc";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Main_FormClosing);
            pnlCalc.ResumeLayout(false);
            pnlCalc.PerformLayout();
            pnlView.ResumeLayout(false);
            this.mnuResult.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tbTerm;
        private System.Windows.Forms.RichTextBox tbView;
        private System.Windows.Forms.ListBox lbHistory;
        private System.Windows.Forms.ContextMenuStrip mnuResult;
        private System.Windows.Forms.ToolStripMenuItem mnuBase;
        private System.Windows.Forms.ToolStripSeparator testToolStripMenuItem;
    }
}

