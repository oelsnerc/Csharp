﻿//********************************************************************
// CNumber_Integer - <type description here>
// (c) Jan 2011 MMC
//********************************************************************
using System;
using System.Collections.Generic;

namespace MMC.Numbers
{
    public class CNumber_Integer : MMC.Numbers.CNumber
    {
        protected List<uint> _Values;
        protected bool _Sign;

        public CNumber_Integer()
        {
            _Values = new List<uint>();
            Clear();
        }

        public CNumber_Integer(double Value)
        {
            _Values = new List<uint>();
            _Sign = (Value < 0.0);
            _Values.Add((uint)(_Sign ? -Value : Value));
        }

        //------------------------------------------------------------
        protected virtual void Clear()
        {
            _Values.Clear();
            _Values.Add(0);
            _Sign = false;
        }

        //------------------------------------------------------------
        // remove all leading zeros
        protected virtual void Trim()
        {
            int i = _Values.Count-1;
            while (i > 0)
            {
                if (_Values[i] == 0) _Values.RemoveAt(i);
                i--;
            }
        }

        //------------------------------------------------------------
        // copy this one
        public override MMC.Numbers.CNumber Clone()
        {
            CNumber_Integer res = new CNumber_Integer();
            res._Values.Clear();
            for (int i = 0; i < _Values.Count; i++)
            {
                res._Values.Add(_Values[i]);
            }
            res._Sign = _Sign;
            return res;
        }

        //------------------------------------------------------------
        public override MMC.Numbers.CNumber.CNumberType MyType { get { return CNumberType.cnt_Integer; } }

        //------------------------------------------------------------
        // convert into a string
        public override string ToString(uint Base)
        {
            // first the sign
            string str = (_Sign) ? "-" : "";

            // numbers of digits separated by '.'
            int step = 4;

            // now the base-indication
            switch (Base)
            {
                case 2: str += "0b"; break;
                case 8: str += "0o"; break;
                case 10: step = 3;  break;
                case 16: str += "0x"; break;
                default: str += '[' + Base.ToString() + ']'; break;
            }

            // if the base is a power of 2
            // let's calc the binary logarithm
            bool poweroftwo = ((Base & (Base - 1)) == 0);
            if (poweroftwo)
            {
                uint b = Base;
                Base = 0;
                while (b > 1) { b >>= 1; Base++; };
            }

            // generate reversed string of digits
            CNumber_Integer tmp = (CNumber_Integer)Clone();
            string num = String.Empty;
            int cnt = 0;
            do
            {
                if (cnt == step) { cnt = 0; num += '.'; }
                uint rem = (poweroftwo) ? tmp.ShiftRight((int) Base) : tmp.Divide(Base);
                num += (char)((rem > 9) ? (rem - 10 + 'A') : (rem + '0'));
                cnt++;
            } while (!tmp.IsZero);

            for (int i = num.Length - 1; i >= 0; i--) str += num[i];
            return str;
        }

        //------------------------------------------------------------
        public override bool FromString(ref string Input)
        {
            Clear();

            // Extract the base of the representation
            uint b = CalcBase(ref Input);
            if (b == 0) return false;       // if illegal ... return nothing
            if (b == 1) return true;        // only a zero

            while (Input.Length > 0)
            {
                char c = Input[0];
                if (c != '.')
                {
                    int n = CalcValue(Input[0]);
                    if (n < 0 || n > (b - 1)) break;
                    Multiply(b);
                    Addition((uint)n);
                }
                Input = Input.Remove(0, 1);
            };

            return true;
        }

        //------------------------------------------------------------
        // to set or get the value as integer
        public override int AsInteger
        {
            get
            {
                return (_Sign) ? (-((int) _Values[0])) : ((int) _Values[0]);
            }
            set
            {
                Clear();
                _Sign = (value < 0);
                _Values[0] = (uint) ((_Sign) ? -value : value);
            }
        }

        //------------------------------------------------------------
        // the little helpers
        public override bool IsZero { get { return (_Values.Count == 1 && _Values[0] == 0); } }

        public override bool IsNegative { get { return _Sign; } }

        public override bool Equals(MMC.Numbers.CNumber other)
        {
            if (other.MyType != MyType) return false;

            CNumber_Integer o = (CNumber_Integer)other;
            if (_Values.Count != o._Values.Count) return false;

            for (int i = 0; i < _Values.Count; i++)
            {
                if (_Values[i] != o._Values[i]) return false;
            }
            return true;
        }

        //------------------------------------------------------------
        // multiply by a power of 2
        // return the remainder
        protected virtual uint ShiftLeft(int Count)
        {
            uint rem = 0;
            int NegCount = 32 - Count;
            for (int i = 0; i < _Values.Count; i++)
            {
                uint v = _Values[i];
                _Values[i] = (v << Count) | rem;
                rem = v >> NegCount;
            }
            if (rem > 0) _Values.Add(rem);
            return rem;
        }

        //------------------------------------------------------------
        // devide by a power of 2
        // return the remainder
        protected virtual uint ShiftRight(int Count)
        {
            uint mask = ((uint)1 << Count) - 1;
            int NegCount = 32 - Count;
            uint rem = 0;
            for (int i = _Values.Count-1; i >= 0; i--)
            {
                uint v = (_Values[i] & mask);
                _Values[i] >>= Count;
                _Values[i] |= (rem << NegCount);
                rem = v;
            }
            Trim();
            return rem;
        }

        //------------------------------------------------------------
        protected virtual void Addition(uint Value)
        {
            if (Value == 0) return;

            _Values[0] = _Values[0] + Value;
            bool rem = (_Values[0] < Value);
            for (int i = 1; rem && (i < _Values.Count); i++)
            {
                _Values[i]++;
                rem = (_Values[i] == 0);
            }
        }

        //------------------------------------------------------------
        protected virtual void Multiply(uint Value)
        {
            if (Value == 0) { Clear(); return; }
            if (Value == 1) return;

            uint rem = 0;
            for (int i = 0; i < _Values.Count; i++)
            {
                ulong v = ((ulong) _Values[i]) * ((ulong) Value) + rem;
                rem = (uint) (v >> 32);
                _Values[i] = (uint)v;
            }
            if (rem > 0) _Values.Add(rem);
        }

        //------------------------------------------------------------
        // divide by an integer and return the remainder
        protected virtual uint Divide(uint Value)
        {
            if (Value == 0) throw new CNumberException("Division by Zero!");
            if (Value == 1) return 0;

            long rem = 0;
            for (int i = _Values.Count-1; i >=0; i--)
            {
                long v = (rem << 32) + (long) _Values[i];
                _Values[i] = (uint) Math.DivRem(v, (long)Value, out rem);
            }
            Trim();
            return (uint) rem;
        }

        //------------------------------------------------------------
        // add a number of shorter of equal length
        protected virtual void Addition(CNumber_Integer other, bool negative)
        {
            ulong rem = 0;
            for (int i = 0; i < other._Values.Count; i++)
            {
                rem += (ulong)_Values[i];
                rem += (ulong)((negative) ? -other._Values[i] : other._Values[i]);
                _Values[i] = (uint)rem;
                rem >>= 32;
                if (rem > 1) _Values[i] = (uint) (-_Values[i]);
            }

            for (int i = other._Values.Count; (rem > 0) && (i < _Values.Count); i++)
            {
                rem = ((ulong)_Values[i]) + rem;
                _Values[i] = (uint)rem;
                rem >>= 32;
            }
            if (rem > 0)
            {
                if (rem > 1)
                    _Sign = !_Sign;
                else
                    _Values.Add(1);
            }
        }

        protected virtual void Addition(CNumber_Integer other)
        {
            ulong rem = 0;
            for (int i = 0; i < other._Values.Count; i++)
            {
                rem = ((ulong)_Values[i]) + ((ulong)other._Values[i]) + rem;
                _Values[i] = (uint)rem;
                rem >>= 32;
            }
            for (int i = other._Values.Count; (rem>0) && (i < _Values.Count); i++)
            {
                rem = ((ulong)_Values[i]) + rem;
                _Values[i] = (uint)rem;
                rem >>= 32;
            }
            if (rem > 0) _Values.Add((uint)rem);
        }

        //------------------------------------------------------------
        // subtract a number of shorter of equal length
        protected virtual void Subtraction(CNumber_Integer other)
        {
            uint rem = 0;
            for (int i = 0; i < other._Values.Count; i++)
            {
                ulong v = (ulong)(other._Values[i] - rem);  // rem is either 0 or -1
                v = (ulong)_Values[i] - v;
                _Values[i] = (uint)v;
                rem = (uint) (v>>32);
            }

            for (int i = other._Values.Count; (rem>0) && (i < _Values.Count); i++)
            {
                ulong v = (ulong)(-rem);
                v = (ulong)_Values[i] - v;
                _Values[i] = (uint)v;
                rem = (uint)(v >> 32);
            }
            if (rem > 0)
            {
                _Values[0] = (uint)(-_Values[0]);
                for (int i = 1; i < _Values.Count; i++)
                {
                    _Values[i] = (uint)(-(_Values[i]+1));
                }
                _Sign = !_Sign;
            }
            Trim();
        }

        //------------------------------------------------------------
        // Helper for subtraction
        protected virtual void Not()
        {
            for (int i = 0; i < _Values.Count; i++)
            {
                _Values[i] = _Values[i] ^ 0;
            }
        }

        //------------------------------------------------------------
        // return a negative version of this one
        public override MMC.Numbers.CNumber neg()
        {
            CNumber_Integer res = (CNumber_Integer) Clone();
            if (!IsZero) res._Sign = !_Sign;
            return res;
        }
        
        //------------------------------------------------------------
        // Arithmetics
        public override MMC.Numbers.CNumber add(MMC.Numbers.CNumber other)
        {
            if (other.MyType != MyType) throw new NotImplementedException();
            CNumber_Integer a = null;
            CNumber_Integer b = null;
            
            int len_this = _Values.Count;
            int len_other = ((CNumber_Integer)other)._Values.Count;
            if (len_other > len_this)
            {
                a = (CNumber_Integer)other.Clone();
                b = this;
            }
            else
            {
                a = (CNumber_Integer)Clone();
                b = (CNumber_Integer)other;
            }

            if (a._Sign != b._Sign)
                a.Subtraction(b);
            else
                a.Addition(b);
            return a;
        }

        public override MMC.Numbers.CNumber sub(MMC.Numbers.CNumber other)
        {
            return add(other.neg());
        }

        public override MMC.Numbers.CNumber mul(MMC.Numbers.CNumber other)
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber div(MMC.Numbers.CNumber other)
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber rem(MMC.Numbers.CNumber other)
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber pow(MMC.Numbers.CNumber a)
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber sqr()
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber sqrt()
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber sin()
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber sinh()
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber cos()
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber cosh()
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber tan()
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber tanh()
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber rad()
        {
            throw new NotImplementedException();
        }

        public override MMC.Numbers.CNumber deg()
        {
            throw new NotImplementedException();
        }
    }
}

//********************************************************************
// END OF FILE CNumber_Integer
//********************************************************************
